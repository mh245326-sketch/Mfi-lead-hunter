// Função da Vercel: guarda a chave do Brave Search no servidor.
// Configure a variável de ambiente BRAVE_API_KEY no painel da Vercel.
export default async function handler(req, res) {
  const q = req.query.q;
  if (!q || !process.env.BRAVE_API_KEY) {
    return res.status(400).json({ error: 'Consulta ou chave ausente' });
  }
  const r = await fetch(
    'https://api.search.brave.com/res/v1/web/search?count=8&country=br&q=' + encodeURIComponent(q),
    { headers: { 'X-Subscription-Token': process.env.BRAVE_API_KEY, Accept: 'application/json' } }
  );
  res.status(r.status).json(await r.json());
}
